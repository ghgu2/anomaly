
import io
from datetime import datetime, timedelta
from typing import Optional
import pandas as pd
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
from hyperopt.pyll.base import scope
from fastapi import FastAPI, File, UploadFile, HTTPException, Request
from fastapi.responses import StreamingResponse, HTMLResponse, JSONResponse, FileResponse
from pydantic import BaseModel
from fastapi.templating import Jinja2Templates
from loguru import logger

app = FastAPI()
templates = Jinja2Templates(directory="templates")

df = pd.DataFrame()
time_series = pd.Series(dtype=np.float64)

class AnomalyRequest(BaseModel):
    start_date: datetime
    end_date: datetime

# Логирование
logger.add("file_{time}.log", rotation="10 MB")

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error: {str(exc)}")
    return JSONResponse(status_code=500, content={"message": "An internal server error occurred"})

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    logger.info("Loading index page")
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    logger.info(f"Received file: {file.filename}")
    try:
        contents = await file.read()
        global df
        # Определение разделителя по расширению файла
        file_extension = file.filename.split('.')[-1].lower()
        if file_extension == 'csv':
            delimiter = ','
        elif file_extension == 'tsv':
            delimiter = '	'
        else:
            logger.error("Unsupported file type")
            raise HTTPException(status_code=400, detail="Unsupported file type. Only CSV and TSV are supported.")

        df = pd.read_csv(io.StringIO(contents.decode('utf-8')), sep=delimiter)
        logger.info(f"File read successfully: {file.filename}")
        if df.empty:
            logger.error("Uploaded file is empty")
            raise HTTPException(status_code=400, detail="Uploaded file is empty")
        process_data()
        logger.info("File processed successfully")
        return {"filename": file.filename}
    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")

def process_data():
    global df, time_series
    try:
        logger.info("Starting data processing")
        columns_to_drop = ['host', 'display_host', 'language', 'pid', 'agent_version', 'labels', 'app_name', 'app_id', 'account_id']
        df = df.drop(columns=columns_to_drop)
        
        df['point'] = pd.to_datetime(df['point'])
        df = df.sort_values(by='point')
        
        nan_indices = df['point'].isna()
        df['point'] = df['point'].interpolate(method='linear')
        df['point'] = df['point'].fillna(method='ffill')
        for idx in df[nan_indices].index:
            if idx > 0 and pd.isna(df.at[idx, 'point']):
                df.at[idx, 'point'] = df.at[idx-1, 'point'] + timedelta(minutes=1)
        
        df = df.fillna(method='ffill')
        df = df.dropna(subset=['point', 'call_count'])
        df['call_count'] = pd.to_numeric(df['call_count'], errors='coerce')
        df = df.dropna(subset=['call_count'])
        time_series = df.set_index('point')['call_count'].resample('T').sum()
        
        if len(time_series) > 15000:
            time_series = time_series[-15000:]
        logger.info("Data processing complete")
    except Exception as e:
        logger.error(f"Error processing data: {str(e)}")
        raise HTTPException(status_code=500, detail="Error processing data")

@app.get("/anomalies_plot/")
async def get_anomalies_plot():
    try:
        if time_series.empty:
            logger.error("No data available")
            raise HTTPException(status_code=400, detail="No data available")

        space = {
            'p': scope.int(hp.quniform('p', 0, 3, 1)),
            'd': scope.int(hp.quniform('d', 0, 2, 1)),
            'q': scope.int(hp.quniform('q', 0, 3, 1)),
            'P': scope.int(hp.quniform('P', 0, 1, 1)),
            'D': scope.int(hp.quniform('D', 0, 1, 1)),
            'Q': scope.int(hp.quniform('Q', 0, 1, 1))
        }

        def objective(params):
            s = 30
            model = SARIMAX(time_series, order=(params['p'], params['d'], params['q']),
                            seasonal_order=(params['P'], params['D'], params['Q'], s))
            results = model.fit(disp=False)
            return {'loss': results.aic, 'status': STATUS_OK}

        logger.info("Starting Bayesian optimization")
        trials = Trials()
        best = fmin(fn=objective, space=space, algo=tpe.suggest, max_evals=10, trials=trials)

        s = 30
        model = SARIMAX(time_series, order=(best['p'], best['d'], best['q']),
                        seasonal_order=(best['P'], best['D'], best['Q'], s))
        results = model.fit(disp=False)
        logger.info(f"Bayesian optimization complete, best parameters: {best}")

        pred = results.get_prediction(start=0, end=len(time_series)-1)
        pred_mean = pred.predicted_mean
        pred_ci = pred.conf_int()

        anomalies = time_series[(time_series < pred_ci.iloc[:, 0]) | (time_series > pred_ci.iloc[:, 1])]

        plt.figure(figsize=(12, 6))
        plt.plot(time_series, label='Observed')
        plt.plot(pred_mean, color='red', label='Forecast')
        plt.fill_between(pred_ci.index,
                         pred_ci.iloc[:, 0],
                         pred_ci.iloc[:, 1], color='k', alpha=0.2, label='Confidence Interval')
        plt.scatter(anomalies.index, anomalies, color='red', label='Anomalies')
        plt.legend()

        buf = io.BytesIO()
        plt.savefig(buf, format='jpg')
        buf.seek(0)
        logger.info("Anomalies plot created successfully")

        # Сохраняем файл графика
        with open('anomalies_plot.jpg', 'wb') as f:
            f.write(buf.getbuffer())

        return FileResponse('anomalies_plot.jpg', media_type='image/jpeg', filename='anomalies_plot.jpg')
    except Exception as e:
        logger.error(f"Error generating anomalies plot: {str(e)}")
        raise HTTPException(status_code=500, detail="Error generating anomalies plot")

@app.post("/result_graph/")
async def get_result_graph(request: AnomalyRequest):
    try:
        if time_series.empty:
            logger.error("No data available")
            raise HTTPException(status_code=400, detail="No data available")

        start_date = request.start_date
        end_date = request.end_date
        filtered_data = time_series[(time_series.index >= start_date) & (time_series.index <= end_date)].to_frame(
            name='call_count')

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            filtered_data.to_excel(writer, index=True, sheet_name='Anomalies')
        output.seek(0)

        # Сохраняем результат в файл
        with open('anomalies.xlsx', 'wb') as f:
            f.write(output.getbuffer())

        logger.info("Result Excel created successfully")
        return FileResponse('anomalies.xlsx', media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename='anomalies.xlsx')
    except Exception as e:
        logger.error(f"Error generating result graph: {str(e)}")
        raise HTTPException(status_code=500, detail="Error generating result graph")
